#include "set.hpp"

set::set(searchable_bag &bag) : _bag(bag)
{

}

set::set(const set &other) : _bag(other._bag)
{

}

set &set::operator=(const set &other)
{
	_bag = other._bag;
	return (*this);
}

set::~set()
{
	
}

void set::insert(int item)
{
	if(!_bag.has(item))
		_bag.insert(item);
}

void set::insert(int *array, int size)
{
	for (int i = 0; i < size; i++)
	{
		if(!_bag.has(array[i]))
			_bag.insert(array[i]);
	}
}

void set::print() const
{
	_bag.print();
}

void set::clear()
{
	_bag.clear();
}

bool set::has(int pattern)
{
	return (_bag.has(pattern));
}

searchable_bag &set::get_bag()
{
	return (_bag);
}